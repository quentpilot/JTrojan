/**
 * @Description:        Trojan class would to run main processes
 * @Author:             Quentin Le Bian <quentpilot>
 * @Email:              quentin.lebian@pilotaweb.fr
 * @Project:            JTrojan
 * @About:              You're welcome to hack and code as your are each of theses sources files <3:p|--<;
 * @Filename:           Trojan.java
 * @Date:               2017-10-19T15:24:18+02:00
 * @Last modified by:   quentpilot
 * @Last modified time: 2017-10-21T12:45:40+02:00
 * @License:            MIT
 * @See:                projects.quentinlebian.fr/JTrojan
 */


package Trojan.Install;

public class Trojan {}
